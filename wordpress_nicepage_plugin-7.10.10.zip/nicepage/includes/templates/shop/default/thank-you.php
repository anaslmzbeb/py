<section class="u-align-center u-clearfix u-container-align-center u-block-c040-9 active" custom-posts-hash="T"
         data-section-properties="{&quot;margin&quot;:&quot;both&quot;,&quot;stretch&quot;:true}" data-id="c040"
         data-style="thank-you-1" id="sec-2278" style="background-image: none">
    <div class="u-clearfix u-sheet u-valign-middle u-block-c040-2" style="min-height: 800px">
        <h2 class="u-align-center u-text u-text-default u-block-c040-11 u-block-control"
            style="margin-top: 60px; margin-left: auto; margin-right: auto; margin-bottom: 0" data-block="25"
            data-block-type="Text"> Thank you for your order</h2>
        <p class="u-align-center u-text u-text-default u-block-c040-12 u-block-control"
           style="margin-top: 20px; margin-left: auto; margin-right: auto; margin-bottom: 60px" data-block="26">Sample
            text. Click to select the Text Element.</p>
        <p class="u-align-center u-text u-text-default u-block-c040-12 u-block-control"
           style="margin-top: 20px; margin-left: auto; margin-right: auto; margin-bottom: 60px" data-block="27"><a
                    href="<?php echo home_url(); ?>">Go back to main page</a></p>
    </div>
    <style data-mode="XL">@media (max-width: 0px) {
            .u-block-c040-9 {
                background-image: none
            }

            .u-block-c040-2 {
                min-height: 800px
            }

            .u-block-c040-11 {
                margin-top: 60px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 0
            }

            .u-block-c040-12 {
                margin-top: 20px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 60px
            }
        }</style>
    <style data-mode="LG">@media (max-width: 0px) {
            .u-block-c040-9 {
                background-image: none
            }

            .u-block-c040-2 {
                min-height: 800px
            }

            .u-block-c040-11 {
                margin-top: 60px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 0
            }

            .u-block-c040-12 {
                margin-top: 20px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 60px
            }
        }</style>
    <style data-mode="MD">@media (max-width: 0px) {
            .u-block-c040-9 {
                background-image: none
            }

            .u-block-c040-2 {
                min-height: 800px
            }

            .u-block-c040-11 {
                margin-top: 60px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 0
            }

            .u-block-c040-12 {
                margin-top: 20px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 60px
            }
        }</style>
    <style data-mode="SM">@media (max-width: 0px) {
            .u-block-c040-9 {
                background-image: none
            }

            .u-block-c040-2 {
                min-height: 800px
            }

            .u-block-c040-11 {
                margin-top: 60px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 0
            }

            .u-block-c040-12 {
                margin-top: 20px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 60px
            }
        }</style>
    <style data-mode="XS">@media (max-width: 0px) {
            .u-block-c040-9 {
                background-image: none
            }

            .u-block-c040-2 {
                min-height: 800px
            }

            .u-block-c040-11 {
                margin-top: 60px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 0
            }

            .u-block-c040-12 {
                margin-top: 20px;
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 60px
            }
        }</style>
</section>
